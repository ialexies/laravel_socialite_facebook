<?php

namespace App\Http\Controllers;

use App\Bunutan;
use Illuminate\Http\Request;

class BunutanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bunutan  $bunutan
     * @return \Illuminate\Http\Response
     */
    public function show(Bunutan $bunutan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bunutan  $bunutan
     * @return \Illuminate\Http\Response
     */
    public function edit(Bunutan $bunutan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bunutan  $bunutan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bunutan $bunutan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bunutan  $bunutan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bunutan $bunutan)
    {
        //
    }
}
