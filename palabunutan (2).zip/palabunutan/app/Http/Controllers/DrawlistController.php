<?php

namespace App\Http\Controllers;

use App\Drawlist;
use Illuminate\Http\Request;

class DrawlistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Drawlist  $drawlist
     * @return \Illuminate\Http\Response
     */
    public function show(Drawlist $drawlist)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Drawlist  $drawlist
     * @return \Illuminate\Http\Response
     */
    public function edit(Drawlist $drawlist)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Drawlist  $drawlist
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Drawlist $drawlist)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Drawlist  $drawlist
     * @return \Illuminate\Http\Response
     */
    public function destroy(Drawlist $drawlist)
    {
        //
    }
}
