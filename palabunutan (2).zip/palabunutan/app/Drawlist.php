<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Drawlist extends Model
{
    //
}
