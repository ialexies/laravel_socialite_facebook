# laravelsocialitegoogle


1. "composer install"
2. "php artisan migrate"
